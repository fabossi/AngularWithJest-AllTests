export enum FilterEnum {
  all = 'all',
  active = 'active',
  completed = 'completed',
}
