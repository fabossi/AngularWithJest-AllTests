export interface UserInteface {
  id: string;
  name: string;
}
